
//TWEEN
	$( document ).mousemove( function( e ) {
		$( '.about-tween' ) .parallax( 70, e );
	});